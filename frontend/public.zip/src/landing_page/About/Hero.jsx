import React from 'react'

const Hero = () => {
  return (
    <div>
      <h1>Hero </h1>
    </div>
  )
}

export default Hero
