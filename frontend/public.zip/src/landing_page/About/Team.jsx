import React from 'react'

const Team = () => {
  return (
    <div>
      <h1>team</h1>
    </div>
  )
}

export default Team
