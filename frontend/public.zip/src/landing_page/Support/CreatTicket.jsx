import React from 'react'

const CreatTicket = () => {
  return (
    <div>
      <h1>CreatTicket</h1>
    </div>
  )
}

export default CreatTicket
