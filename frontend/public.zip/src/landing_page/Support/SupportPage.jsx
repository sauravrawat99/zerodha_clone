import React from "react";
import Hero from "./Hero";
import CreatTicket from "./CreatTicket";

const SupportPage = () => {
  return (
    <div>
      <Hero />
      <CreatTicket />
    </div>
  );
};

export default SupportPage;
