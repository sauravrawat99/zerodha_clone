import React from 'react'

const Brockrage = () => {
  return (
    <div>
      <h1>Broackrange</h1>
    </div>
  )
}

export default Brockrage
