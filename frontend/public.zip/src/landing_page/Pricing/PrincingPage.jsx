import React from "react";
import Home from "./Home";
import Brockrage from "./Brockrage";

const PrincingPage = () => {
  return (
    <>
      <Home />
      <Brockrage />
    </>
  );
};

export default PrincingPage;
