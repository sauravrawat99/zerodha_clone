import React from 'react'

const Universe = () => {
  return (
    <div>
      <h1>Universe</h1>
    </div>
  )
}

export default Universe
