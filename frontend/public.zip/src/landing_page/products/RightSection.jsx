import React from 'react'

const RightSection = () => {
  return (
    <div>
      <h1>RightSection</h1>
    </div>
  )
}

export default RightSection
