import React from 'react'

const LeftSection = () => {
  return (
    <div>
      <h1>Leftsection</h1>
    </div>
  )
}

export default LeftSection
